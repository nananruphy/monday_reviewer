package com.example.akosombotour;

import android.content.Context;

import java.util.ArrayList;

public class ToursitesModel {
    private final String history;

    public ToursitesModel(String history) {
        this.history = history;
    }

    public String getHistory() {
        return history;
    }

    public static ArrayList<ToursitesModel> getUsers(Context context) {
        ArrayList<ToursitesModel> history = new ArrayList<ToursitesModel>();
        return history;
    }
}


