package com.example.akosombotour;

import android.content.Context;

import java.util.ArrayList;

public class EthnicgroupsModel {
    private String history;

    public EthnicgroupsModel(String history) {
        this.history = history;
    }

    public String getHistory() {
        return history;
    }

    public static ArrayList<EthnicgroupsModel> getUsers(Context context) {
        ArrayList<EthnicgroupsModel> history = new ArrayList<EthnicgroupsModel>();
        return history;
    }
}
